import java.util.Scanner;

public class Sesión1 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("1.Comprobar si un número es primo.");
        System.out.println("2.Escribir los n primeros números primos.");
        System.out.println("3.Escribir números primos gemelos entre dos valores.");
        System.out.println("4.Número par como suma de dos primos.");
        System.out.println("0.Finalizar la ejecución.");
        System.out.println(" ");
        System.out.print("Introduzca la opcón deseada: ");
        int menú;
        menú = teclado.nextInt();
        if (menú > 5)
            System.out.println("Opción incorrecta.");
        if (0 > menú)
            System.out.println("Opción incorrecta.");
        switch (menú) {
            case 1:
                System.out.println("Has elegido la opción 1");
                break;
            case 2:
                System.out.println("Has elegido la opción 2");
                break;
            case 3:
                System.out.println("Has elegido la opción 3");
                break;
            case 4:
                System.out.println("Has elegido la opción 4");
                break;
            case 0:
                System.out.println("Has elegido la opción 0");
        }
        System.out.print("Introduce un número entre 0 y 1000: ");
        int número;
        número = teclado.nextInt();
        if (número > 0 && número < 10000)
            System.out.println(número);
        if (número < 0)
            System.out.println("El número no cumple las condiciones ");
        if (número > 1000)
            System.out.println("El número no cumple las condiciones ");

        int n1, n2;
        System.out.println("Escribe el primer número: ");
        n1 = teclado.nextInt();
        System.out.println("Escribe el segundo número: ");
        n2 = teclado.nextInt();
        if (n1 <= n2) {
            System.out.println("Se cumple la condición n1<=n2");
        } else {
            System.out.println("No se cumple la condición n1<=2");
        }
        if (n2 % n1 == 0) {
            System.out.println("Se cumple la condición n2%n1 ==0");
        } else {
            System.out.println("No se cumple la condición n2%n1 ==0");
        }
    }
}